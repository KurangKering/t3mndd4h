<div class="main-sidebar sidebar-style-2">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <img src="{{ base_url('assets/img/logo.png') }}" alt="">
      <a href="{{ base_url('#') }}">
        SISTEM HAJI
      </a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="{{ base_url('#') }}">Hj</a>
    </div>
    <ul class="sidebar-menu">

      <li class="menu-header">Starter</li>
      
      <li><a class="nav-link" href="{{ base_url('dashboard') }}"><i class="far fa-square"></i> <span>Dashboard</span></a></li>

      @if ($user['role'] == "prov")
      <li><a class="nav-link" href="{{ base_url('data-pengguna') }}"><i class="far fa-square"></i> <span>Pengguna</span></a></li>
      @endif

      @if ($user['role'] == "prov")

      <li><a class="nav-link" href="{{ base_url('data-kota') }}"><i class="far fa-square"></i> <span>Data Kota/Kabupaten</span></a></li>
      @endif


      <li><a class="nav-link" href="{{ base_url('data-haji') }}"><i class="far fa-square"></i> <span>Data Haji</span></a></li>

      @if ($user['role'] == "kota")

      <li><a class="nav-link" href="{{ base_url('opsihaji') }}"><i class="far fa-square"></i> <span>Data Regu & Rombongan</span></a></li>
      @endif

      @if ($user['role'] == "prov")

      <li><a class="nav-link" href="{{ base_url('treemap') }}"><i class="far fa-square"></i> <span>Treemap</span></a></li>
      @endif


      {{-- <li class="dropdown">
        <a href="{{ base_url('#') }}" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Layout</span></a>
        <ul class="dropdown-menu">
          <li><a class="nav-link" href="{{ base_url('layout-default.html') }}">Default Layout</a></li>
          <li><a class="nav-link" href="{{ base_url('layout-transparent.html') }}">Transparent Sidebar</a></li>
          <li><a class="nav-link" href="{{ base_url('layout-top-navigation.html') }}">Top Navigation</a></li>
        </ul>
      </li> --}}
    </ul>

  </aside>
</div>